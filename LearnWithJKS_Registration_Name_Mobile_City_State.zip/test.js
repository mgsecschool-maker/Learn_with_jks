
const ADMIN='JKS2026', cats=['materials','tests','schedule','notices','results'];let quizNow=null,questionCount=0;
function get(k){try{return JSON.parse(localStorage.getItem('jks_'+k)||'[]')}catch(e){return []}}function put(k,v){localStorage.setItem('jks_'+k,JSON.stringify(v))}
function register(){
 const n=document.getElementById('nm').value.trim();
 const m=document.getElementById('mob').value.trim();
 const city=document.getElementById('city').value.trim();
 const state=document.getElementById('state').value.trim();
 if(!n||!/^[0-9]{10}$/.test(m)||!city||!state){alert('कृपया नाम, 10 अंकों का मोबाइल नंबर, शहर और राज्य भरें।');return}
 const student={n,m,city,state};
 localStorage.setItem('jks_student',JSON.stringify(student));
 document.getElementById('auth').classList.add('hidden');
 document.getElementById('auth').style.display='none';
 document.getElementById('studentCorner').classList.remove('hidden');
 document.getElementById('studentCorner').style.display='block';
 showStudent();
 document.getElementById('greet').textContent='स्वागत है, '+n+'!';
}
function showStudent(){
 const authEl=document.getElementById('auth'), corner=document.getElementById('studentCorner');
 authEl.classList.add('hidden'); authEl.style.display='none';
 corner.classList.remove('hidden'); corner.style.display='block';
 ['materials','tests','results','ranking','schedule','notices'].forEach(id=>{const el=document.getElementById(id);if(el){el.classList.add('hidden');el.style.display='none'}});
 const s=JSON.parse(localStorage.getItem('jks_student')||'{}');
 document.getElementById('who').textContent=(s.n||'विद्यार्थी')+' · '+(s.m||'')+' · '+(s.city||'')+', '+(s.state||'')+' · आपका Student Corner';
}
function renderStudent(){
 const authEl=document.getElementById('auth'), corner=document.getElementById('studentCorner');
 try{
  const s=JSON.parse(localStorage.getItem('jks_student')||'null');
  if(s&&s.n&&s.m&&s.city&&s.state){
   document.getElementById('nm').value=s.n; document.getElementById('mob').value=s.m; document.getElementById('city').value=s.city; document.getElementById('state').value=s.state;
   document.getElementById('greet').textContent='स्वागत है, '+s.n+'!';
   showStudent();
  }else{
   authEl.classList.remove('hidden');authEl.style.display='block';
   corner.classList.add('hidden');corner.style.display='none';
  }
 }catch(e){authEl.classList.remove('hidden');authEl.style.display='block';corner.classList.add('hidden');corner.style.display='none'}
}
function go(id){if(!localStorage.getItem('jks_student')){alert('पहले विद्यार्थी रजिस्ट्रेशन करें।');return}['materials','tests','results','ranking','schedule','notices'].forEach(x=>document.getElementById(x).classList.add('hidden'));document.getElementById(id).classList.remove('hidden');document.getElementById(id).scrollIntoView({behavior:'smooth'})}
function adminOpen(){if(pw.value!==ADMIN){alert('पासवर्ड सही नहीं है।');return}adminForm.classList.remove('hidden');kindChange();renderAll()}
let logoTaps=0,logoTimer=null;document.getElementById('logoMark').addEventListener('click',()=>{logoTaps++;clearTimeout(logoTimer);logoTimer=setTimeout(()=>logoTaps=0,1800);if(logoTaps>=5){logoTaps=0;admin.classList.remove('hidden');admin.scrollIntoView({behavior:'smooth'});alert('Admin login खोल दिया गया है।')}});
function kindChange(){questionsForm.classList.toggle('hidden',kind.value!=='tests');}
function addQuestionFields(){if(questionCount>=50){alert('डेमो में एक टेस्ट में अधिकतम 50 प्रश्न जोड़े जा सकते हैं।');return}questionCount++;let box=document.createElement('div');box.className='item';box.innerHTML=`<b>प्रश्न ${questionCount}</b><input class="qq" placeholder="प्रश्न लिखें"><input class="oa" placeholder="विकल्प A"><input class="ob" placeholder="विकल्प B"><input class="oc" placeholder="विकल्प C"><input class="od" placeholder="विकल्प D"><select class="correct"><option value="0">सही उत्तर A</option><option value="1">सही उत्तर B</option><option value="2">सही उत्तर C</option><option value="3">सही उत्तर D</option></select>`;qRows.appendChild(box)}
function addItem(){let k=kind.value,t=title.value.trim(),u=url.value.trim(),d=date.value.trim(),desc=document.getElementById('desc').value.trim();if(!t){alert('शीर्षक भरें।');return}let item={t,u,d,desc,created:new Date().toISOString()};if(k==='tests'){let boxes=[...qRows.children];item.questions=boxes.map(b=>({q:b.querySelector('.qq').value.trim(),opts:['oa','ob','oc','od'].map(c=>b.querySelector('.'+c).value.trim()),correct:+b.querySelector('.correct').value})).filter(q=>q.q&&q.opts.every(Boolean));if(!item.questions.length&&!u){alert('कम से कम एक पूरा प्रश्न या टेस्ट लिंक जोड़ें।');return}}let a=get(k);a.unshift(item);put(k,a);title.value='';url.value='';date.value='';desc.value='';qRows.innerHTML='';questionCount=0;renderAll();alert('जानकारी इस फोन पर सेव हुई। यह दूसरे विद्यार्थियों के फोन पर अपने आप नहीं पहुँचेगी।')}
function renderList(k,id){let el=document.getElementById(id),a=get(k);el.innerHTML='';if(!a.length){el.innerHTML='<p class="muted">अभी सामग्री नहीं जोड़ी गई।</p>';return}a.forEach((x,i)=>{let d=document.createElement('div');d.className='item';let b=document.createElement('b');b.textContent=x.t;d.appendChild(b);let p=document.createElement('p');p.className='muted';p.textContent=[x.d,x.desc].filter(Boolean).join(' · ');d.appendChild(p);if(x.u){let a=document.createElement('a');a.href=x.u;a.target='_blank';a.rel='noopener';a.className='button';a.textContent='खोलें / डाउनलोड करें';d.appendChild(a)}if(k==='tests'&&x.questions&&x.questions.length){let b2=document.createElement('button');b2.textContent='टेस्ट शुरू करें ('+x.questions.length+' प्रश्न)';b2.onclick=()=>startTest(i);d.appendChild(b2)}if(!document.getElementById('adminForm').classList.contains('hidden')){let del=document.createElement('button');del.className='alt';del.textContent='यह सामग्री हटाएँ';del.onclick=()=>deleteItem(k,i);d.appendChild(del)}el.appendChild(d)})}
function deleteItem(k,i){if(document.getElementById('adminForm').classList.contains('hidden')){alert('पहले Admin Panel खोलें।');return}if(!confirm('क्या यह सामग्री हटानी है?'))return;let a=get(k);a.splice(i,1);put(k,a);renderAll();alert('सामग्री इस फोन से हटा दी गई।')}
function adminLock(){adminForm.classList.add('hidden');pw.value='';admin.classList.add('hidden');renderAll()}
function startTest(i){let x=get('tests')[i];if(!x||!x.questions||!x.questions.length){alert('इस टेस्ट में MCQ नहीं हैं; लिंक खोलें।');return}quizNow={test:x,answers:{},idx:0};quiz.classList.remove('hidden');renderQuestion();go('quiz')}
function renderQuestion(){let q=quizNow.test.questions[quizNow.idx],idx=quizNow.idx;quiz.innerHTML=`<h3>प्रश्न ${idx+1}/${quizNow.test.questions.length}</h3><p>${escapeHtml(q.q)}</p>`;q.opts.forEach((o,j)=>{let b=document.createElement('button');b.className='option alt';b.textContent=String.fromCharCode(65+j)+'. '+o;b.onclick=()=>{quizNow.answers[idx]=j;[...quiz.querySelectorAll('button.option')].forEach((z,n)=>z.style.borderColor=n===j?'#0877e8':'#d6e5f5')};if(quizNow.answers[idx]===j)b.style.borderColor='#0877e8';quiz.appendChild(b)});let nav=document.createElement('div');nav.className='row';if(idx>0){let prev=document.createElement('button');prev.className='alt';prev.textContent='पिछला';prev.onclick=()=>{quizNow.idx--;renderQuestion()};nav.appendChild(prev)}let next=document.createElement('button');next.textContent=idx===quizNow.test.questions.length-1?'टेस्ट जमा करें':'अगला';next.onclick=()=>{if(quizNow.answers[idx]===undefined){alert('पहले उत्तर चुनें।');return}if(idx===quizNow.test.questions.length-1)finishTest();else{quizNow.idx++;renderQuestion()}};nav.appendChild(next);quiz.appendChild(nav)}
function finishTest(){let qs=quizNow.test.questions,ans=quizNow.answers,correct=qs.filter((q,i)=>ans[i]===q.correct).length;let result={t:quizNow.test.t,score:correct,total:qs.length,pct:Math.round(correct/qs.length*100),date:new Date().toLocaleString(),detail:qs.map((q,i)=>({q:q.q,chosen:ans[i],correct:q.correct,opts:q.opts}))};let r=get('results');r.unshift(result);put('results',r);quiz.innerHTML=`<h3>टेस्ट परिणाम</h3><div class="score">${correct}/${qs.length}</div><p style="text-align:center">${result.pct}% अंक</p><button onclick="showAnalysis(0)">उत्तर विश्लेषण देखें</button>`;quizNow=null;renderAll()}
function showAnalysis(i){let r=get('results')[i];if(!r||!r.detail){alert('पुराने परिणाम में विश्लेषण उपलब्ध नहीं।');return}let el=document.getElementById('resultsList');el.innerHTML=`<h3>${escapeHtml(r.t)} — ${r.score}/${r.total} (${r.pct}%)</h3>`;r.detail.forEach((q,n)=>{let d=document.createElement('div');d.className='item';let p=document.createElement('p');p.textContent=(n+1)+'. '+q.q;d.appendChild(p);q.opts.forEach((o,j)=>{let op=document.createElement('div');op.className='option '+(j===q.correct?'good':(j===q.chosen?'bad':''));op.textContent=String.fromCharCode(65+j)+'. '+o+(j===q.correct?' ✓ सही उत्तर':'')+(j===q.chosen&&j!==q.correct?' ✗ आपका उत्तर':'');d.appendChild(op)});el.appendChild(d)});go('results')}
function renderResults(){let el=resultsList,r=get('results');el.innerHTML='';if(!r.length){el.innerHTML='<p class="muted">अभी कोई परिणाम नहीं है।</p>';return}r.forEach((x,i)=>{let d=document.createElement('div');d.className='item';d.innerHTML=`<b>${escapeHtml(x.t)}</b><p class="muted">${x.date} · ${x.score}/${x.total} · ${x.pct}%</p>`;let b=document.createElement('button');b.className='alt';b.textContent='विस्तृत विश्लेषण';b.onclick=()=>showAnalysis(i);d.appendChild(b);el.appendChild(d)})}
function renderRank(){let el=rankList,r=get('results');el.innerHTML='';if(!r.length){el.textContent='अभी परिणाम नहीं हैं।';return}let best=Math.max(...r.map(x=>x.pct));el.textContent='इस डिवाइस पर आपका सर्वश्रेष्ठ परिणाम: '+best+'%';}
function renderAll(){renderList('materials','materialsList');renderList('tests','testsList');renderList('schedule','scheduleList');renderList('notices','noticesList');renderResults();renderRank()}
function escapeHtml(s){return String(s||'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}
function share(){if(navigator.share)navigator.share({title:'Learn With JKS',text:'Learn With JKS ऐप'}).catch(()=>{});else alert('APK को फोन के Share विकल्प से साझा करें।')}
function restoreBackup(e){if(document.getElementById('adminForm').classList.contains('hidden')){alert('पहले Admin Panel खोलें।');return}let f=e.target.files[0];if(!f)return;let r=new FileReader();r.onload=()=>{try{let o=JSON.parse(r.result);cats.forEach(k=>{if(Array.isArray(o[k]))put(k,o[k])});renderAll();alert('बैकअप वापस लोड हो गया।')}catch(err){alert('यह सही JSON बैकअप नहीं है।')}e.target.value=''};r.readAsText(f)}
function backup(){let o={};cats.forEach(k=>o[k]=get(k));let a=document.createElement('a');a.href=URL.createObjectURL(new Blob([JSON.stringify(o,null,2)],{type:'application/json'}));a.download='LearnWithJKS-backup.json';a.click();setTimeout(()=>URL.revokeObjectURL(a.href),1000)}
renderStudent();renderAll();
