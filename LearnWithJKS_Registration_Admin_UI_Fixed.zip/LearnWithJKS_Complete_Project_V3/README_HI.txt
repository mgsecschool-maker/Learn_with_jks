Learn With JKS — One complete source ZIP

इस पैकेज में Android Studio/ GitHub Actions के लिए Android WebView प्रोजेक्ट और नया नीला-सफेद UI शामिल है।

APK बनाने का तरीका:
1. ZIP को extract करें।
2. GitHub repository के root में ZIP के अंदर की फाइलें upload करें (ZIP को सीधे repository में डालना पर्याप्त नहीं है)।
3. GitHub > Actions > Build Learn With JKS APK > Run workflow चलाएँ।
4. सफल build के बाद Learn-With-JKS-APK artifact डाउनलोड करें।

डेमो सीमाएँ:
- रजिस्ट्रेशन, सामग्री, MCQ, परिणाम और विश्लेषण अभी इस डिवाइस के local storage पर हैं।
- डेमो Admin password: JKS2026 (इसे वास्तविक सुरक्षित admin login न समझें)।
- Firebase/ऑनलाइन backend, shared student data/rankings, सुरक्षित admin rules, push notifications, वास्तविक PDF सामग्री और 100 विद्यार्थियों का load test अभी शामिल/सत्यापित नहीं हैं।
- Telegram बटन चैनल https://t.me/learn_with_jks खोलता है।
- यह source ZIP है; APK इस पैकेज में prebuilt नहीं है।


नया बदलाव (10 अक्टूबर 2026): आपकी L1_Test_Paper HTML फ़ाइल app/src/main/assets/L1_Test_Paper.html में जोड़ी गई है और Student Corner के Online Test भाग से खोली जा सकती है। इसे अभी Android पर बिल्ड करके जाँचा नहीं गया है। Firebase/backend, साझा ऑनलाइन रैंकिंग और push notifications अभी सेटअप नहीं हैं।


FIREBASE CONFIGURATION (2026-10-10)
- Added the supplied app/google-services.json for Firebase project learn-with-jks and package com.learnwithjks.app.
- Added Google Services Gradle plugin and Firebase BoM, Firestore, and Auth SDK dependencies.
- IMPORTANT: this only configures the SDK. The existing demo UI has not yet been rewritten to use Firestore/Auth. Shared student data, secure admin authorization, Firestore rules, and push notifications are NOT finished by this configuration alone.
- Before production, configure Firebase Authentication providers, create restrictive Firestore Security Rules, and test the app build.
