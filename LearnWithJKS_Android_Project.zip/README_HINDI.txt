Learn With JKS Android project

इस ZIP में असली Android Gradle project है, सिर्फ index.html नहीं।
Package name: com.learnwithjks.app
Firebase project: learn-with-jks-a3d26

महत्वपूर्ण:
1. Firebase Console > Authentication > Sign-in method में Phone provider enable करें।
2. Firebase Console में Android app के SHA-1 और SHA-256 fingerprints जोड़ें। बिना fingerprints के कुछ फोन पर OTP verification विफल हो सकता है।
3. OTP/SMS quota और Firebase phone-auth settings लागू होती हैं।
4. APK GitHub Actions से build होगा; ZIP को repository के root में LearnWithJKS_Android_Project.zip नाम से upload करना है।
5. इसके बाद repository में .github/workflows/main.yml को दिए गए नए workflow से बदलें।
