package com.learnwithjks.app;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebSettings;
import android.widget.Toast;

import com.google.firebase.FirebaseException;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseAuthInvalidCredentialsException;
import com.google.firebase.auth.PhoneAuthCredential;
import com.google.firebase.auth.PhoneAuthOptions;
import com.google.firebase.auth.PhoneAuthProvider;

import java.util.concurrent.TimeUnit;

public class MainActivity extends Activity {
    private WebView webView;
    private FirebaseAuth auth;
    private String verificationId;
    private PhoneAuthProvider.ForceResendingToken resendToken;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        auth = FirebaseAuth.getInstance();
        webView = new WebView(this);
        setContentView(webView);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        webView.setWebChromeClient(new WebChromeClient());
        webView.setWebViewClient(new WebViewClient());
        webView.addJavascriptInterface(new AppBridge(), "AndroidApp");
        webView.loadUrl("file:///android_asset/index.html");
    }

    private void js(String script) {
        runOnUiThread(() -> webView.evaluateJavascript(script, null));
    }

    private class AppBridge {
        @JavascriptInterface
        public void sendOtp(String phone) {
            String normalized = phone == null ? "" : phone.trim().replace(" ", "");
            if (normalized.matches("\\d{10}")) normalized = "+91" + normalized;
            if (!normalized.matches("\\+[1-9]\\d{7,14}")) {
                js("otpError('सही मोबाइल नंबर दर्ज करें।')");
                return;
            }
            final String phoneNumber = normalized;
            PhoneAuthOptions options = PhoneAuthOptions.newBuilder(auth)
                .setPhoneNumber(phoneNumber)
                .setTimeout(60L, TimeUnit.SECONDS)
                .setActivity(MainActivity.this)
                .setCallbacks(new PhoneAuthProvider.OnVerificationStateChangedCallbacks() {
                    @Override
                    public void onVerificationCompleted(PhoneAuthCredential credential) {
                        auth.signInWithCredential(credential).addOnCompleteListener(task -> {
                            if (task.isSuccessful()) js("loginSuccess()");
                            else js("otpError('OTP सत्यापन नहीं हो सका।')");
                        });
                    }

                    @Override
                    public void onVerificationFailed(FirebaseException e) {
                        String msg = e.getMessage() == null ? "OTP नहीं भेजा जा सका।" : e.getMessage();
                        msg = msg.replace("\\", "\\\\").replace("'", "\\'").replace("\n", " ");
                        js("otpError('" + msg + "')");
                    }

                    @Override
                    public void onCodeSent(String id, PhoneAuthProvider.ForceResendingToken token) {
                        verificationId = id;
                        resendToken = token;
                        js("otpSent()");
                    }
                }).build();
            PhoneAuthProvider.verifyPhoneNumber(options);
        }

        @JavascriptInterface
        public void verifyOtp(String code) {
            if (verificationId == null) {
                js("otpError('पहले OTP भेजें।')");
                return;
            }
            String otp = code == null ? "" : code.trim();
            if (!otp.matches("\\d{6}")) {
                js("otpError('6 अंकों का OTP दर्ज करें।')");
                return;
            }
            PhoneAuthCredential credential = PhoneAuthProvider.getCredential(verificationId, otp);
            auth.signInWithCredential(credential).addOnCompleteListener(task -> {
                if (task.isSuccessful()) js("loginSuccess()");
                else {
                    Exception ex = task.getException();
                    String msg = "गलत OTP या सत्यापन विफल।";
                    if (ex instanceof FirebaseAuthInvalidCredentialsException) msg = "गलत OTP। दोबारा जाँचें।";
                    js("otpError('" + msg + "')");
                }
            });
        }

        @JavascriptInterface
        public void logout() {
            auth.signOut();
            js("showLogin()");
        }
    }

    @Override
    public void onBackPressed() {
        js("handleBack()");
    }
}
