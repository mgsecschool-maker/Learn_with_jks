Learn With JKS - शुरुआती Android WebView प्रोजेक्ट

इस प्रोजेक्ट में शामिल:
- नीला-सफेद Student Corner UI
- नाम/मोबाइल का स्थानीय रजिस्ट्रेशन
- विषय सामग्री के शुरुआती सेक्शन
- ऐप शेयर और Telegram लिंक
- शामिल L1 टेस्ट HTML: app/src/main/assets/tests/l1_test.html
- GitHub Actions APK build workflow: .github/workflows/build-apk.yml

APK बनाने के लिए:
1. इस ZIP को extract करें और इसकी अंदर की workjks वाली सामग्री GitHub repository की main branch के root में डालें (यानी app/, build.gradle, settings.gradle, .github/ root पर हों)।
2. GitHub में Actions खोलें; Build Learn With JKS APK workflow चलाएँ या push के बाद build पूरा होने दें।
3. सफल run में Artifacts से Learn-With-JKS-APK डाउनलोड करें।

महत्वपूर्ण सीमाएँ:
- यह अभी शुरुआती स्थानीय डेमो है, production-ready ऐप नहीं।
- रजिस्ट्रेशन/एडमिन द्वारा जोड़ी सामग्री अभी सभी विद्यार्थियों में साझा नहीं होती; ऑनलाइन backend/database और file storage अभी जोड़ना बाकी है।
- Admin password को client-side HTML/JavaScript में रखना सुरक्षित admin authentication नहीं है। वास्तविक उपयोग से पहले server-side authentication/authorization लागू करें।
- 1000 विद्यार्थियों की क्षमता अभी सत्यापित नहीं है; backend और load testing के बाद ही पुष्टि हो सकती है।
