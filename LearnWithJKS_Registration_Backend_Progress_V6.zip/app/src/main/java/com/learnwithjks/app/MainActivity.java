package com.learnwithjks.app;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.JavascriptInterface;
import android.graphics.Color;
import org.json.JSONObject;
import org.json.JSONArray;
import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import java.util.HashMap;
import java.util.Map;

public class MainActivity extends Activity {
    private WebView web;
    private FirebaseAuth auth;
    private FirebaseFirestore db;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(7, 91, 190));
        getWindow().setNavigationBarColor(Color.rgb(5, 55, 115));
        web = new WebView(this);
        web.setBackgroundColor(Color.rgb(237, 245, 255));
        WebSettings settings = web.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        web.setWebViewClient(new WebViewClient());
        setContentView(web);
        try {
            FirebaseApp.initializeApp(this);
            auth = FirebaseAuth.getInstance();
            db = FirebaseFirestore.getInstance();
            web.addJavascriptInterface(new FirebaseBridge(), "JKSNative");
            FirebaseUser current = auth.getCurrentUser();
            if (current == null) {
                auth.signInAnonymously();
            }
        } catch (Exception e) {
            // UI remains available and reports backend initialization errors through bridge status.
        }
        web.loadUrl("file:///android_asset/index.html");
    }

    private void jsCallback(String callback, String payload) {
        if (web == null) return;
        String safeName = callback == null ? "" : callback.replaceAll("[^A-Za-z0-9_$]", "");
        if (safeName.isEmpty()) return;
        final String script = safeName + "(" + JSONObject.quote(payload == null ? "" : payload) + ");";
        runOnUiThread(() -> web.evaluateJavascript(script, null));
    }

    public class FirebaseBridge {
        @JavascriptInterface public void getBackendStatus(String cb) {
            String s = (db != null && auth != null) ? "firebase_ready" : "firebase_unavailable";
            jsCallback(cb, s);
        }

        @JavascriptInterface public void saveStudentProfile(String json, String cb) {
            if (db == null || auth == null) { jsCallback(cb, "ERROR:Firebase initialize नहीं हुआ"); return; }
            FirebaseUser u = auth.getCurrentUser();
            if (u == null) { jsCallback(cb, "ERROR:कनेक्शन/लॉगिन तैयार नहीं है, दोबारा कोशिश करें"); return; }
            try {
                JSONObject p = new JSONObject(json);
                Map<String,Object> data = new HashMap<>();
                data.put("uid", u.getUid());
                data.put("name", p.optString("name"));
                data.put("mobile", p.optString("mobile"));
                data.put("city", p.optString("city"));
                data.put("registeredAt", p.optString("registeredAt"));
                data.put("updatedAt", System.currentTimeMillis());
                db.collection("students").document(u.getUid()).set(data)
                    .addOnSuccessListener(v -> jsCallback(cb, "OK:" + u.getUid()))
                    .addOnFailureListener(e -> jsCallback(cb, "ERROR:" + e.getMessage()));
            } catch (Exception e) { jsCallback(cb, "ERROR:" + e.getMessage()); }
        }

        @JavascriptInterface public void loadStudentProfile(String cb) {
            if (db == null || auth == null || auth.getCurrentUser() == null) { jsCallback(cb, ""); return; }
            String uid = auth.getCurrentUser().getUid();
            db.collection("students").document(uid).get()
                .addOnSuccessListener(doc -> {
                    if (!doc.exists()) { jsCallback(cb, ""); return; }
                    Map<String,Object> m = doc.getData();
                    try { jsCallback(cb, new JSONObject(m).toString()); }
                    catch (Exception e) { jsCallback(cb, ""); }
                }).addOnFailureListener(e -> jsCallback(cb, "ERROR:" + e.getMessage()));
        }

        @JavascriptInterface public void loginAdmin(String email, String password, String cb) {
            if (auth == null || db == null) { jsCallback(cb, "ERROR:Firebase initialize नहीं हुआ"); return; }
            auth.signInWithEmailAndPassword(email, password)
                .addOnSuccessListener(result -> {
                    FirebaseUser u = result.getUser();
                    if (u == null) { jsCallback(cb, "ERROR:लॉगिन विफल"); return; }
                    db.collection("admins").document(u.getUid()).get()
                        .addOnSuccessListener(doc -> {
                            if (doc.exists() && Boolean.TRUE.equals(doc.getBoolean("active"))) jsCallback(cb, "OK:" + u.getUid());
                            else { auth.signOut(); jsCallback(cb, "ERROR:यह अकाउंट एडमिन के रूप में अधिकृत नहीं है"); }
                        }).addOnFailureListener(e -> { auth.signOut(); jsCallback(cb, "ERROR:" + e.getMessage()); });
                }).addOnFailureListener(e -> jsCallback(cb, "ERROR:लॉगिन विफल। ईमेल/पासवर्ड जाँचें"));
        }

        @JavascriptInterface public void addContent(String type, String json, String cb) {
            if (db == null || auth == null || auth.getCurrentUser() == null) { jsCallback(cb, "ERROR:पहले एडमिन लॉगिन करें"); return; }
            String uid = auth.getCurrentUser().getUid();
            db.collection("admins").document(uid).get().addOnSuccessListener(admin -> {
                if (!admin.exists() || !Boolean.TRUE.equals(admin.getBoolean("active"))) { jsCallback(cb, "ERROR:एडमिन अनुमति नहीं है"); return; }
                if (!("materials".equals(type) || "tests".equals(type) || "notices".equals(type) || "classes".equals(type) || "schedule".equals(type))) { jsCallback(cb, "ERROR:गलत कंटेंट प्रकार"); return; }
                try {
                    Map<String,Object> item = new JSONObject(json).toMap();
                    item.put("createdAt", System.currentTimeMillis());
                    item.put("createdBy", uid);
                    db.collection("content").document(type).collection("items").add(item)
                        .addOnSuccessListener(ref -> jsCallback(cb, "OK:" + ref.getId()))
                        .addOnFailureListener(e -> jsCallback(cb, "ERROR:" + e.getMessage()));
                } catch (Exception e) { jsCallback(cb, "ERROR:" + e.getMessage()); }
            }).addOnFailureListener(e -> jsCallback(cb, "ERROR:" + e.getMessage()));
        }

        @JavascriptInterface public void loadContent(String type, String cb) {
            if (db == null) { jsCallback(cb, "ERROR:Firebase initialize नहीं हुआ"); return; }
            if (!("materials".equals(type) || "tests".equals(type) || "notices".equals(type) || "classes".equals(type) || "schedule".equals(type))) { jsCallback(cb, "[]"); return; }
            db.collection("content").document(type).collection("items").get()
                .addOnSuccessListener(snapshot -> {
                    JSONArray arr = new JSONArray();
                    for (QueryDocumentSnapshot doc : snapshot) {
                        JSONObject o = new JSONObject(doc.getData());
                        try { o.put("id", doc.getId()); } catch (Exception ignored) {}
                        arr.put(o);
                    }
                    jsCallback(cb, arr.toString());
                }).addOnFailureListener(e -> jsCallback(cb, "ERROR:" + e.getMessage()));
        }

        @JavascriptInterface public void logoutAdmin(String cb) {
            if (auth != null) auth.signOut();
            if (auth != null) auth.signInAnonymously().addOnCompleteListener(t -> jsCallback(cb, "OK"));
            else jsCallback(cb, "ERROR:Firebase initialize नहीं हुआ");
        }
    }

    @Override public void onBackPressed() {
        if (web != null && web.canGoBack()) web.goBack();
        else super.onBackPressed();
    }
}
