Learn With JKS - No OTP Starter

यह शुरुआती Android WebView प्रोजेक्ट है। इसमें:
- नाम और मोबाइल नंबर से स्थानीय रजिस्ट्रेशन (OTP नहीं)
- PDF / Online Classes / Test Schedule के लिए Admin Panel demo
- Telegram चैनल बटन
- लोकल डिवाइस में सेव होने वाला डेमो डेटा

महत्वपूर्ण सीमाएँ:
1. Admin demo password अभी JKS2026 है। यह असुरक्षित डेमो पासवर्ड है; सार्वजनिक रूप से उपयोग करने से पहले बदलें।
2. डेटा केवल उसी डिवाइस/ऐप में सेव होता है। अन्य विद्यार्थियों तक एक जैसा डेटा पहुँचाने के लिए Firebase/ऑनलाइन डेटाबेस और वास्तविक admin authentication जोड़ना आवश्यक है।
3. Quiz/results अभी placeholder हैं।
4. इस ZIP को GitHub Actions से APK बनाने के लिए workflow अलग से सेट करना होगा.
