Learn With JKS — Updated Source ZIP

इस ZIP में Android WebView starter project और नया नीला-सफेद UI शामिल है।
मुख्य फाइल: app/src/main/assets/index.html

शामिल:
- विद्यार्थी नाम/10-अंकों का मोबाइल रजिस्ट्रेशन (लोकल डिवाइस)
- नीला-सफेद Student Corner और 2-column सुविधा बटन
- PDF सामग्री की विषय सूची
- Admin से PDF/क्लास/टेस्ट शेड्यूल/नोटिस लिंक जोड़ना
- इस फोन पर लोकल सेव और JSON backup/restore
- 3 प्रश्नों वाला डेमो क्विज़, स्कोर, उत्तर विश्लेषण और लोकल परिणाम सूची
- Learn With JKS Telegram चैनल लिंक

डेमो Admin password: JKS2026
पासवर्ड को रिलीज़ से पहले बदलें। यह सुरक्षित ऑनलाइन प्रमाणीकरण नहीं है।

महत्वपूर्ण सीमाएँ:
- यह ZIP सोर्स प्रोजेक्ट है, APK नहीं।
- वास्तविक बहु-विद्यार्थी डेटाबेस, सुरक्षित Admin login, cloud PDF storage, push notifications,
  ऑनलाइन सभी विद्यार्थियों की ranking, तथा असली प्रश्नपत्र/आपकी HTML quiz file का integration
  इसमें अभी नहीं है। इन्हें Firebase/सर्वर और अतिरिक्त कोड से बनाना होगा।
- क्विज़ के प्रश्न केवल डेमो हैं; इन्हें वास्तविक परीक्षा के प्रश्न न समझें।

APK बनाने के लिए GitHub Actions में ZIP अपलोड करके workflow चलाएँ। ZIP के भीतर प्रोजेक्ट
फोल्डर को extract करके gradle assembleDebug चलना चाहिए (Java 17 और Gradle 8.9)।
