# Learn With JKS — बाकी काम और अंतिम सेटअप

## इस पैकेज में पहले से मौजूद
- Android WebView ऐप का source
- बिना OTP का स्थानीय demo registration
- स्थानीय demo Admin Panel
- L1 test HTML: `app/src/main/assets/tests/l1_test.html`
- GitHub Actions से debug APK बनाने की workflow

## अभी वास्तव में बाकी है
यह प्रोजेक्ट अभी पूर्ण ऑनलाइन quiz platform नहीं है। निम्न सुविधाएँ backend जोड़ने और परीक्षण के बाद ही चालू मानी जाएँगी:
1. सभी विद्यार्थियों के लिए साझा cloud database
2. Admin की server-verified पहचान और role-based permissions
3. Online test attempts, server-side score validation, duplicate submission protection
4. सभी विद्यार्थियों की ranking और पुराने results
5. PDFs की cloud storage तथा download permissions
6. New test/notice push notifications
7. 100 concurrent students का load test

## Firebase backend शुरू करने के लिए
1. अपने Google खाते से Firebase Console में नया project बनाएं।
2. Firestore Database और Authentication सेट करें।
3. Android app को Firebase में register करें; सही `google-services.json` ऐप के `app/` फ़ोल्डर में रखें। इस ZIP में कोई वास्तविक Firebase credentials नहीं हैं।
4. `backend/firebase/firestore.rules.example` को पढ़कर अपनी जरूरत के अनुसार rules configure करें। इसे बिना समीक्षा के production में publish न करें।
5. Admin account को Firebase Authentication में बनाएं और trusted server/Admin SDK से admin role दें। Client से स्वयं को admin बनाने की अनुमति न दें।
6. Server-side scoring और result/ranking के लिए Cloud Functions या trusted backend बनाएं। केवल client-side सही उत्तरों पर भरोसा न करें।
7. Push notifications के लिए Firebase Cloud Messaging और server trigger जोड़ें।
8. 100 test accounts/devices के साथ concurrency, access control, reconnect और duplicate submit की जाँच करें।

## Security warning
- Demo password `JKS2026` production password नहीं है।
- Mobile number को अकेले identity verification नहीं माना जा सकता, क्योंकि OTP नहीं है।
- Firestore rules की example file केवल starting point है; actual collections और Authentication flow से मिलाए बिना deploy न करें।
- Firebase service-account private key या admin credentials कभी GitHub में upload न करें।

## APK workflow
GitHub repository में source files रखने के बाद Actions > Build Learn With JKS APK workflow चलाएँ। Successful run के Artifacts से debug APK ZIP डाउनलोड करें। Debug APK सार्वजनिक production distribution का आदर्श विकल्प नहीं है; release signing अलग से configure करनी होगी।
