Learn With JKS - Android Source Project
======================================

यह ZIP GitHub पर APK build करने के लिए source project है।

इसमें शामिल:
- Android WebView app shell
- बिना OTP नाम/मोबाइल registration (local demo)
- PDF / online class / test schedule links जोड़ने का local Admin demo
- L1 टेस्ट HTML फाइल: app/src/main/assets/tests/l1_test.html
- GitHub Actions workflow: .github/workflows/build-apk.yml

APK बनाने के चरण:
1. ZIP extract करें।
2. इस ZIP के अंदर मौजूद workjks फ़ोल्डर की सामग्री अपनी GitHub repository के root में upload करें (या repo को इस project से replace करें)।
3. GitHub > Actions में Build Learn With JKS APK workflow चलाएँ।
4. सफल run में Artifacts से Learn-With-JKS-APK डाउनलोड करें। ZIP extract करके app-debug.apk install करें।

महत्वपूर्ण सीमाएँ:
- यह अभी local/demo version है। Admin द्वारा जोड़ी सामग्री उसी फोन में localStorage में रहती है।
- साझा online database, सुरक्षित server-side admin login, push notifications, cross-student results/ranking अभी configure नहीं हैं।
- 100 विद्यार्थियों के concurrent test के लिए backend/database, access rules, server-side scoring और load testing आवश्यक हैं। केवल इस ZIP/APK से 100-student online system तैयार नहीं हो जाता।
- Admin password source code में demo-only है; इसे वास्तविक सुरक्षा न मानें।
- L1 HTML टेस्ट को Android WebView में run करके जाँचना आवश्यक है।

कृपया पुराने working repository/ZIP का backup रखे बिना delete न करें।

बाकी backend सेटअप और सुरक्षा की checklist के लिए `REMAINING_WORK_HI.md` तथा `backend/firebase/README_HI.md` देखें।
