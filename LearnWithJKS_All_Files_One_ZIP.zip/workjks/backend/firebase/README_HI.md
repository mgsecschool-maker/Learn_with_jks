# Firebase backend notes

यह folder backend setup की शुरुआती सामग्री है, ready-to-deploy backend नहीं।

- `google-services.json` अपने Firebase Android app registration से लें; यहाँ कोई credential शामिल नहीं है।
- Firestore rules example में sign-in आवश्यक है। वर्तमान demo का name/mobile-only local registration Firebase Authentication नहीं है, इसलिए ये rules सीधे वर्तमान ऐप के साथ काम नहीं करेंगे जब तक Authentication flow जोड़ा न जाए।
- Test scoring, admin role assignment और notifications trusted server/Cloud Functions से लागू करें।
- `JKS2026` को वास्तविक सुरक्षा न मानें और production में hard-coded password न रखें।
